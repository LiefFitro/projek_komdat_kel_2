<?php
include 'config.php';
$id = $_POST['id_barang'];
$jumlah = $_POST['jumlah'];
$penerima = $_POST['penerima'];
mysqli_query($koneksi, "INSERT INTO barang_keluar (id_barang, jumlah, penerima) VALUES ($id, $jumlah, '$penerima')");
mysqli_query($koneksi, "UPDATE barang SET stok = stok - $jumlah WHERE id_barang = $id");
header("Location: barangkeluar.php");
?>
