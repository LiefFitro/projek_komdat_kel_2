<?php
include 'koneksi.php';

// Ambil data barang
$barang_result = mysqli_query($conn, "SELECT * FROM barang");

$notif = "";
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $id_barang = $_POST['id_barang'];
    $jumlah = (int) $_POST['jumlah'];
    $tanggal = $_POST['tanggal'];

    $stok_result = mysqli_query($conn, "SELECT stok FROM barang WHERE id_barang = $id_barang");
    $stok_data = mysqli_fetch_assoc($stok_result);

    if ($stok_data && $stok_data['stok'] >= $jumlah && $jumlah > 0) {
        $insert = mysqli_query($conn, "INSERT INTO barang_keluar (id_barang, jumlah, tanggal) VALUES ('$id_barang', '$jumlah', '$tanggal')");
        if ($insert) {
            mysqli_query($conn, "UPDATE barang SET stok = stok - $jumlah WHERE id_barang = $id_barang");
            $notif = "<div class='alert alert-success'>Barang keluar berhasil disimpan.</div>";
        } else {
            $notif = "<div class='alert alert-danger'>Gagal menyimpan data.</div>";
        }
    } else {
        $notif = "<div class='alert alert-warning'>Jumlah melebihi stok atau tidak valid.</div>";
    }
}

// Ambil data barang keluar beserta gambar
$riwayat = mysqli_query($conn, "
    SELECT bk.tanggal, b.nama_barang, b.gambar, bk.jumlah
    FROM barang_keluar bk
    JOIN barang b ON bk.id_barang = b.id_barang
    ORDER BY bk.tanggal DESC
");
?>

<!DOCTYPE html>
<html>
<head>
    <title>Barang Keluar</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        body {
            display: flex;
            height: 100vh;
            overflow: hidden;
        }
        .sidebar {
            width: 240px;
            background-color:  #343a40;
            color: #;
            padding: 20px;
        }
        .sidebar h4 {
            margin-bottom: 30px;
            
        }
        .sidebar a {
            display: block;
            color: white;
            text-decoration: none;
            margin-bottom: 10px;
            padding: 10px;
            border-radius: 5px;
        }
        .sidebar a:hover, .sidebar a.active {
            background-color: #34495e;
        }
        .main-content {
            flex: 1;
            padding: 30px;
            overflow-y: auto;
        }
    </style>
</head>
<body>
    <div class="sidebar">
        <h4 style="color:white;">Lab Komunikasi Data</h4>
        <a href="index.php">📦 Stock Barang</a>
        <a href="barangmasuk.php">📥 Barang Masuk</a>
        <a class="active" href="barangkeluar.php">📤 Barang Keluar</a>
    </div>

    <div class="main-content">
        <h2>Barang Keluar</h2>
        <?= $notif ?>
        <form method="post" class="row g-3 mb-4">
            <div class="col-md-6">
                <label class="form-label">Pilih Barang</label>
                <select name="id_barang" class="form-select" required>
                    <option value="">Pilih barang</option>
                    <?php while ($row = mysqli_fetch_assoc($barang_result)) { ?>
                        <option value="<?= $row['id_barang'] ?>"><?= $row['nama_barang'] ?></option>
                    <?php } ?>
                </select>
            </div>
            <div class="col-md-3">
                <label class="form-label">Jumlah</label>
                <input type="number" name="jumlah" class="form-control" required>
            </div>
            <div class="col-md-3">
                <label class="form-label">Tanggal</label>
                <input type="date" name="tanggal" class="form-control" required>
            </div>
            <div class="col-12">
                <button class="btn btn-primary">Tambah</button>
            </div>
        </form>

        <h4>Riwayat Barang Keluar</h4>
        <table class="table table-bordered table-striped">
            <!-- Tambahkan kolom "Kembali" -->
<thead>
  <tr>
    <th>Tanggal Pinjam</th>
    <th>Nama Barang</th>
    <th>Gambar</th>
    <th>Jumlah</th>
    <th>Tanggal Kembali</th>
    <th>Barang Kembali</th>
  </tr>
</thead>
<tbody>
<?php
$data = mysqli_query($conn, "
    SELECT bk.id, bk.tanggal, b.nama_barang, b.gambar, bk.jumlah, bk.kembali, bk.tanggal_kembali
    FROM barang_keluar bk
    JOIN barang b ON bk.id_barang = b.id_barang
    ORDER BY bk.tanggal DESC
");

while ($d = mysqli_fetch_array($data)) {
?>
  <tr>
    <td><?= $d['tanggal']; ?></td>
    <td><?= $d['nama_barang']; ?></td>
    <td><img src="gambar/<?= $d['gambar']; ?>" width="80"></td>
    <td><?= $d['jumlah']; ?></td>
    <td>
      <form action="kembali.php" method="post" class="d-flex">
        <input type="hidden" name="id" value="<?= $d['id']; ?>">
        <input type="date" name="tanggal_kembali" class="form-control me-2"
               value="<?= $d['tanggal_kembali']; ?>" <?= $d['kembali'] ? 'readonly' : '' ?>>
    </td>
    <td>
        <input type="checkbox" name="kembali" value="1" <?= $d['kembali'] ? 'checked disabled' : '' ?>>
        <?php if (!$d['kembali']) { ?>
            <button type="submit" class="btn btn-sm btn-success ms-2">Simpan</button>
        <?php } ?>
      </form>
    </td>
  </tr>
<?php } ?>
</tbody>


        </table>
    </div>
</body>
</html>
