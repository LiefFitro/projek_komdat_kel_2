<?php
include 'koneksi.php';

$id = $_GET['id'];
$query = mysqli_query($conn, "SELECT * FROM barang WHERE id_barang = '$id'");
$data = mysqli_fetch_assoc($query);

if (isset($_POST['update'])) {
    $nama = $_POST['nama_barang'];
    $deskripsi = $_POST['deskripsi'];
    $stok = $_POST['stok'];

    $gambar = $_FILES['gambar']['name'];
    $tmp = $_FILES['gambar']['tmp_name'];

    // Jika user upload gambar baru
    if ($gambar) {
        $target = "gambar/" . basename($gambar);
        move_uploaded_file($tmp, $target);

        // Hapus gambar lama
        if (!empty($data['gambar'])) {
            $old_path = 'gambar/' . $data['gambar'];
            if (file_exists($old_path)) {
                unlink($old_path);
            }
        }

        // Update semua data
        $update = mysqli_query($conn, "UPDATE barang SET nama_barang='$nama', deskripsi='$deskripsi', stok='$stok', gambar='$gambar' WHERE id_barang='$id'");
    } else {
        // Update tanpa gambar
        $update = mysqli_query($conn, "UPDATE barang SET nama_barang='$nama', deskripsi='$deskripsi', stok='$stok' WHERE id_barang='$id'");
    }

    if ($update) {
        header("Location: index.php");
        exit;
    } else {
        echo "<div class='alert alert-danger'>Gagal update data.</div>";
    }
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Edit Barang</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body class="container mt-4">
    <h2>Edit Barang</h2>

    <form method="post" enctype="multipart/form-data">
        <div class="mb-3">
            <label>Nama Barang</label>
            <input type="text" name="nama_barang" class="form-control" value="<?= $data['nama_barang']; ?>" required>
        </div>
        <div class="mb-3">
            <label>Deskripsi</label>
            <textarea name="deskripsi" class="form-control"><?= $data['deskripsi']; ?></textarea>
        </div>
        <div class="mb-3">
            <label>Stok</label>
            <input type="number" name="stok" class="form-control" value="<?= $data['stok']; ?>" required>
        </div>
        <div class="mb-3">
            <label>Gambar</label><br>
            <?php if ($data['gambar']) { ?>
                <img src="gambar/<?= $data['gambar']; ?>" width="100"><br><br>
            <?php } ?>
            <input type="file" name="gambar" class="form-control">
        </div>
        <button type="submit" name="update" class="btn btn-success">Update</button>
        <a href="index.php" class="btn btn-secondary">Kembali</a>
    </form>
</body>
</html>
