<?php
include 'config.php';
$nama = $_POST['nama_barang'];
mysqli_query($koneksi, "INSERT INTO barang (nama_barang, stok) VALUES ('$nama', 0)");
header("Location: index.php");
?>
