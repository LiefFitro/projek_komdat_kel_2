<?php
include 'config.php';
if (!isset($_SESSION['login'])) {
    header("Location: login.php");
    exit;
}

require 'koneksi.php';
$barang = mysqli_query($conn, "SELECT * FROM barang");
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>Stock Barang</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
  <link rel="stylesheet" href="path/to/font-awesome/css/font-awesome.min.css">
  <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons/font/bootstrap-icons.css" rel="stylesheet">
  <style>
    body {
      display: flex;
      min-height: 100vh;
    }
    .sidebar {
      width: 240px;
      background-color: #343a40;
      color: #fff;
      padding-top: 20px;
    }
    .sidebar a {
      color: #fff;
      display: block;
      padding: 12px 20px;
      text-decoration: none;
    }
    .sidebar a:hover, .sidebar .active {
      background-color: #495057;
    }
    .content {
      flex-grow: 1;
      padding: 30px;
      background-color: #f8f9fa;
    }
    img.barang-img {
      width: 80px;
      height: auto;
      border-radius: 5px;
    }
  </style>
</head>
<body>

  <!-- Sidebar -->
  <div class="sidebar">
    <h4 class="text-center mb-4">Lab komunikasi data</h4>
    <a href="index.php" class="active"><i class=""></i>📦 Stock Barang</a>
    <a href="barangmasuk.php"><i class=""></i>📥 Barang Masuk</a>
    <a href="barangkeluar.php"><i class=""></i>📥 Barang Keluar</a>
    <a href="logout.php" class="list-group-item list-group-item-action bg-danger text-white mt-4"><span class="glyphicon glyphicon-log-out" ></span>  Logout</a>
  </div>

  <!-- Content -->
  <div class="content">
    <div class="row">
      <div class="col-md-3 d-flex justify-content-between align-items-center mb-3">
        <h3>Export Ke Excel</h3>
        <a href="excel.php" class="btn btn-primary">Export</a>
      </div>
      <div class="col-md-3 d-flex justify-content-between align-items-center mb-3">
        <h3>Stock Barang</h3>
        <a href="tambahbarang.php" class="btn btn-primary">Tambah Barang</a>
      </div>
      
    </div>

    <table class="table table-bordered table-hover bg-white">
      <thead class="table-light">
        <tr>
          <th>No</th>
          <th>Nama Barang</th>
          <th>Gambar</th>
          <th>Spesifikasi</th>
          <th>Kondisi</th>
          <th>Stock</th>
          <th>Edit</th>
        </tr>
      </thead>
     <tbody>
  <?php
  $no = 1;
  while ($row = mysqli_fetch_assoc($barang)) {
  ?>
  <tr>
    <td><?= $no++; ?></td>
    <td><?= htmlspecialchars($row['nama_barang']); ?></td>
    <td>
      <?php if (!empty($row['gambar'])): ?>
        <img src="gambar/<?= htmlspecialchars($row['gambar']); ?>" width="80">
      <?php else: ?>
        Tidak ada
      <?php endif; ?>
    </td>
    <td><?= htmlspecialchars($row['spesifikasi']); ?></td>
    <td><?= htmlspecialchars($row['deskripsi']); ?></td>
    <td><?= htmlspecialchars($row['stok']); ?></td>
    <td>
      <a href="editbarang.php?id=<?= $row['id_barang']; ?>" class="btn btn-warning btn-sm">Edit</a>
      <a href="hapusbarang.php?id=<?= $row['id_barang']; ?>" class="btn btn-danger btn-sm" onclick="return confirm('Yakin ingin menghapus barang ini?')">Hapus</a>
    </td>
  </tr>
  <?php } ?>
</tbody>

    </table>
  </div>

</body>
</html>
