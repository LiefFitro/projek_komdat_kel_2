<?php
include 'koneksi.php';

$notif = "";

if (isset($_POST['simpan'])) {
    $nama = $_POST['nama_barang'];
    $spesifikasi = $_POST['spesifikasi'];
    $deskripsi = $_POST['deskripsi'];
    $stok = $_POST['stok'];
    $gambar = $_FILES['gambar']['name'];
    $tmp = $_FILES['gambar']['tmp_name'];

    if ($nama && is_numeric($stok)) {
        if ($gambar != "") {
            $target = "gambar/" . basename($gambar);
            move_uploaded_file($tmp, $target);
        } else {
            $gambar = null;
        }

        $insert = mysqli_query($conn, "INSERT INTO barang (nama_barang, spesifikasi, deskripsi, stok, gambar) 
        VALUES ('$nama','$spesifikasi', '$deskripsi', '$stok', '$gambar')");

        if ($insert) {
            $notif = "<div class='alert alert-success'>Barang berhasil ditambahkan.</div>";
        } else {
            $notif = "<div class='alert alert-danger'>Gagal menyimpan data.</div>";
        }
    } else {
        $notif = "<div class='alert alert-warning'>Isi nama barang dan stok dengan benar.</div>";
    }
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Tambah Barang</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body class="container mt-4">
    <h2>Tambah Barang</h2>
    <?= $notif ?>

    <form method="post" enctype="multipart/form-data">
        <div class="mb-3">
            <label class="form-label">Nama Barang</label>
            <input type="text" name="nama_barang" class="form-control" required>
        </div>
        <div class="mb-3">
            <label class="form-label">Spesifikasi</label>
            <textarea name="spesifikasi" class="form-control" rows="3" required></textarea>
        </div>
        <div class="mb-3">
            <label class="form-label">Kondisi</label>
            <textarea name="deskripsi" class="form-control" rows="3" required></textarea>
        </div>
        <div class="mb-3">
            <label class="form-label">Stok</label>
            <input type="number" name="stok" class="form-control" required>
        </div>
        <div class="mb-3">
            <label class="form-label">Upload Gambar</label>
            <input type="file" name="gambar" class="form-control" accept="image/*">
        </div>
        <button type="submit" name="simpan" class="btn btn-primary">Simpan</button>
        <a href="index.php" class="btn btn-secondary">Kembali</a>
    </form>
</body>
</html>
