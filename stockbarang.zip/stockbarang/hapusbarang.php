<?php
include 'koneksi.php';

if (isset($_GET['id'])) {
    $id = $_GET['id'];

    // Hapus gambar jika ada
    $get = mysqli_query($conn, "SELECT gambar FROM barang WHERE id_barang = '$id'");
    $data = mysqli_fetch_assoc($get);
    if (!empty($data['gambar'])) {
        $path = 'gambar/' . $data['gambar'];
        if (file_exists($path)) {
            unlink($path); // hapus gambar fisik
        }
    }

    // Hapus data barang
    $delete = mysqli_query($conn, "DELETE FROM barang WHERE id_barang = '$id'");
}

header("Location: index.php");
exit;
