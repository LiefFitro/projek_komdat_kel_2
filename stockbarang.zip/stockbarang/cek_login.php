<?php
include 'config.php';

$username = $_POST['username'];
$password = $_POST['password'];

// Cek apakah user sudah ada
$cek_user = mysqli_query($koneksi, "SELECT * FROM user WHERE username='$username'");
$jumlah = mysqli_num_rows($cek_user);

if ($jumlah > 0) {
    // User ditemukan, cek password
    $data = mysqli_fetch_assoc($cek_user);
    if ($data['password'] == $password) {
        $_SESSION['login'] = true;
        header("Location: index.php");
    } else {
        // Password salah
        echo "<script>alert('Password salah!'); window.location='login.php';</script>";
    }
} else {
    // Username belum ada → buat user baru otomatis
    mysqli_query($koneksi, "INSERT INTO user (username, password) VALUES ('$username', '$password')");
    $_SESSION['login'] = true;
    header("Location: index.php");
}
?>
