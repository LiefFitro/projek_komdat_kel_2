<?php
include 'config.php';
require 'koneksi.php';

// Proses form barang masuk
if (isset($_POST['barangmasuk'])) {
    $idbarang = $_POST['idbarang'];
    $qty = $_POST['qty'];
    $tanggal = $_POST['tanggal']; // Ambil dari input

    // Tambahkan ke tabel barang_masuk
    $insert = mysqli_query($conn, "INSERT INTO barang_masuk (id_barang, tanggal, qty) 
                                   VALUES ('$idbarang', '$tanggal', '$qty')");

    // Tambahkan stok ke tabel barang
    if ($insert) {
        mysqli_query($conn, "UPDATE barang SET stok = stok + $qty WHERE id_barang = '$idbarang'");
        header('Location: barangmasuk.php');
    } else {
        echo 'Gagal menambahkan data';
    }
}

// Ambil daftar barang untuk dropdown
$barang = mysqli_query($conn, "SELECT * FROM barang");

// Ambil data barang masuk
$datamasuk = mysqli_query($conn, "
    SELECT bm.tanggal, b.nama_barang, bm.qty
    FROM barang_masuk bm 
    JOIN barang b ON bm.id_barang = b.id_barang
    ORDER BY bm.id DESC
");
?>

<!DOCTYPE html>
<html>
<head>
  <meta charset="UTF-8">
  <title>Barang Masuk</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
  <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons/font/bootstrap-icons.css" rel="stylesheet">
  <style>
    body { display: flex; min-height: 100vh; }
    .sidebar { width: 240px; background-color: #343a40; color: #fff; padding-top: 20px; }
    .sidebar a { color: #fff; display: block; padding: 12px 20px; text-decoration: none; }
    .sidebar a:hover, .sidebar .active { background-color: #495057;  }
    .content { flex-grow: 1; padding: 30px; background-color: #f8f9fa; }
  </style>
</head>
<body>
  <div class="sidebar">
    <h4 class="text-center mb-4">Lab Komunikasi Data</h4>
    <a href="index.php"><i class=""></i>📦 Stock Barang</a>
    <a href="barangmasuk.php" class="active"><i class=""></i> 📥 Barang Masuk</a>
    <a href="barangkeluar.php"><i class=""></i>📤 Barang Keluar</a>
  </div>
  <div class="content">
    <h3 class="mb-4">Barang Masuk</h3>
    <form method="POST" class="row g-3 mb-4">
      <div class="col-md-4">
        <label class="form-label">Pilih Barang</label>
        <select name="idbarang" class="form-select" required>
          <option selected disabled>Pilih barang</option>
          <?php while ($b = mysqli_fetch_array($barang)) { ?>
            <option value="<?= $b['id_barang'] ?>"><?= $b['nama_barang'] ?></option>
          <?php } ?>
        </select>
      </div>
      <div class="col-md-3">
        <label class="form-label">Jumlah</label>
        <input type="number" name="qty" class="form-control" required>
      </div>
      <div class="col-md-3">
        <label class="form-label">Tanggal</label>
        <input type="date" name="tanggal" class="form-control" required>
      </div>
      <div class="col-md-2 d-flex align-items-end">
        <button type="submit" name="barangmasuk" class="btn btn-primary w-100">Tambah</button>
      </div>
    </form>

    <table class="table table-bordered table-hover bg-white">
  <thead class="table-light">
    <tr>
      <th>Tanggal</th>
      <th>Nama Barang</th>
      <th>Gambar</th>
      <th>Jumlah</th>
    </tr>
  </thead>
  <tbody>
    <?php
    $ambil = mysqli_query($conn, "SELECT bm.*, b.nama_barang, b.gambar 
                                  FROM barang_masuk bm 
                                  JOIN barang b ON bm.id_barang = b.id_barang 
                                  ORDER BY bm.tanggal DESC");
    while ($data = mysqli_fetch_array($ambil)) {
    ?>
    <tr>
      <td><?= $data['tanggal']; ?></td>
      <td><?= htmlspecialchars($data['nama_barang']); ?></td>
      
<td>
  <?php if (!empty($data['gambar'])): ?>
    <img src="gambar/<?= htmlspecialchars($data['gambar']); ?>" width="80">
  <?php else: ?>
    Tidak ada
  <?php endif; ?>
</td>

      <td><?= $data['qty']; ?></td>
    </tr>
    <?php } ?>
  </tbody>
</table>

  </div>
</body>
</html>
