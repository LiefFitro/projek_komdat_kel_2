<?php
include 'koneksi.php';

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $id = $_POST['id'];
    $tanggal_kembali = $_POST['tanggal_kembali'] ?? null;
    $kembali = isset($_POST['kembali']) ? 1 : 0;

    // Ambil data barang_keluar untuk tahu id_barang dan jumlahnya
    $cek = mysqli_query($conn, "SELECT id_barang, jumlah, kembali FROM barang_keluar WHERE id = $id");
    $data = mysqli_fetch_assoc($cek);

    if ($data && !$data['kembali'] && $kembali && $tanggal_kembali) {
        $id_barang = $data['id_barang'];
        $jumlah = $data['jumlah'];

        // Tambahkan stok barang
        mysqli_query($conn, "UPDATE barang SET stok = stok + $jumlah WHERE id_barang = $id_barang");

        // Update status kembali
        mysqli_query($conn, "
            UPDATE barang_keluar 
            SET kembali = 1, tanggal_kembali = '$tanggal_kembali' 
            WHERE id = $id
        ");
    }
}

header("Location: barangkeluar.php");
exit;
?>
