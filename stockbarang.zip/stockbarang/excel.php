<?php
include 'koneksi.php'; // file koneksi ke database

header("Content-Type: application/vnd.ms-excel");
header("Content-Disposition: attachment; filename=data_barang.xls");

echo "<table border='1'>";
echo "<tr>
        <th>ID</th>
        <th>Nama Barang</th>
        <th>spesifikasi</th>
        <th>deskripsi</th>
        <th>Stok</th>
        
    </tr>";

$query = mysqli_query($conn, "SELECT * FROM barang");
while($row = mysqli_fetch_assoc($query)) {
    echo "<tr>
            <td>".$row['id_barang']."</td>
            <td>".$row['nama_barang']."</td>
            <td>".$row['spesifikasi']."</td>
            <td>".$row['deskripsi']."</td>
            <td>".$row['stok']."</td>
             
        </tr>";
}
echo "</table>";
?>
